#include <stdio.h>
#include <stdlib.h>

int main(){
    char name[32];
    int age = 18;

    printf("%s","Who are you?\n>>> ");
    fgets(name, 512, stdin);

    printf("Hello %s", name);

    if(age > 18){
        system("cat flag.txt");
    }
    else{
        puts("Oh no! You must older than 18");
    }

    return 0;
}