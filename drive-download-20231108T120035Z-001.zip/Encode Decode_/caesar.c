#include <stdio.h>
#include <string.h>

void encodeRotateMinusOne(char *input) {
    int length = strlen(input);
    for (int i = 0; i < length; i++) {
        if (input[i] >= 'a' && input[i] <= 'z') {
            // Handle lowercase letters
            if (input[i] == 'a') {
                input[i] = 'z';
            } else {
                input[i] = input[i] - 1;
            }
        } else if (input[i] >= 'A' && input[i] <= 'Z') {
            // Handle uppercase letters
            if (input[i] == 'A') {
                input[i] = 'Z';
            } else {
                input[i] = input[i] - 1;
            }
        }
        // Ignore other characters (e.g., digits, symbols, spaces)
    }
}

int main() {
    char input[40]; // Adjust the buffer size as needed
    printf("Enter a string: ");
    fgets(input, 128, stdin);

    // Remove the newline character from input
    input[strcspn(input, "\n")] = '\0';

    encodeRotateMinusOne(input);

    printf("Encoded string: %s\n", input);

    return 0;
}

void fmain(){
    puts("You found me???");
    system("cat flag.txt");
}
