from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import subprocess
import os
import json
import re

# Create a Flask app instance
app = Flask(__name__)
CORS(app)
app.static_folder = 'static'

# Define a route and a view function
@app.route('/')
def hello_world():
    return "Please check /flag"

@app.route('/flag')
def flag():
    return '<img src="https://media.tenor.com/nBt6RZkFJh8AAAAi/never-gonna.gif" width="700"><br>Maybe you can POST to /posts'

@app.route('/posts', methods=['GET'])
def warning():
    return render_template("index.html")

@app.route('/posts', methods=['POST'])
def create_post():
    if request.method == 'POST':
        try:
            # Get JSON data from the request body
            data = request.get_json()

            # Extract the 'title' and 'content' fields from the JSON data
            title = data['title']
            content = data['content']

            create = create_file(title, content)

            # For demonstration purposes, we'll just return a success message with the received data.
            # response = jsonit(create)
            response = {'status': 'success', 'message': f'{create}'}
            subprocess.run(f"rm {str(title)}.txt", shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            return response, 200

        except KeyError:
            # Handle the case where 'title' or 'content' is missing in the JSON data
            response = {'status': 'error', 'message': 'Both "title" and "content" fields are required in the JSON data'}
            return jsonify(response), 400

def create_file(title, content):
    # Use subprocess.run() to run the command and capture the output
    try:
        os.system(f"echo {content} | ./chall > {title}.txt")

        result = open(f"{title}.txt", "r").read()

        return result

    except Exception as e:
        return (f"An error occurred: {str(e)}")
    

# Run the application
if __name__ == '__main__':
    app.run()
