#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    int filesize = 11;

    char content[24];
    fgets(content, 128, stdin);

    if(strstr(content, "gIve_m3_fL4g") == NULL){
        printf("Invalid");
        return 1;
    }

    printf("%s", content);

    if(filesize > 1266446){
        system("cat flag.txt");
    }
}